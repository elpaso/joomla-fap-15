alter table `#__menu` add column accesskey char(1);
