alter table `#__menu` drop column accesskey;
alter table `#__menu` drop column title;