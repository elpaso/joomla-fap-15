<?php // @version $Id: default.php 36 2008-04-03 06:26:47Z elpaso $
defined('_JEXEC') or die('Restricted access');
?>

<h1 class="componentheading">
	<?php echo JText::_('Welcome!'); ?>
</h1>

<div class="contentdescription">
	<?php echo JText::_('WELCOME_DESC'); ?>
</div>
