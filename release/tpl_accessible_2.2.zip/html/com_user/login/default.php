<?php // @version $Id: default.php 36 2008-04-03 06:26:47Z elpaso $
defined( '_JEXEC' ) or die( 'Restricted access' );

echo $this->loadTemplate( $this->type );
