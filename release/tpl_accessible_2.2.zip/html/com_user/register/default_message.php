<?php // @version $Id: default_message.php 36 2008-04-03 06:26:47Z elpaso $
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<h3>
	<?php echo $this->message->title; ?>
</h3>

<p class="message">
	<?php echo $this->message->text; ?>
</p>
