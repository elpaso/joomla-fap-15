<?php
require_once dirname(__FILE__) . '/../overrides/blog.php';
?>