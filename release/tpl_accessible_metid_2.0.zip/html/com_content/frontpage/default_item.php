<?php
include dirname(__FILE__) . '/../overrides/blog_item.php';
?>
